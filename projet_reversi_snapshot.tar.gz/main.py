from game.game_manager import GameManager

if __name__ == "__main__":
    gm = GameManager()
    gm.run()