from ui.messages import *

def game_setup():
  print_slowly(MSG_WELCOME)